import PropTypes from 'prop-types';
import { Card, Button } from 'react-bootstrap';
import { useDispatch } from 'react-redux';
import { addToCart } from '../redux/cart/cartSlice';
import { reduceServiceQuantity } from '../redux/service/serviceThunk';

export default function ServiceCard({ service, isAdmin = false, onEdit, onDelete }) {
  const dispatch = useDispatch();

  const handleAdd = () => {
    dispatch(addToCart({ type: 'service', item: { ...service, quantity: 1 } }));
    dispatch(reduceServiceQuantity(service.id));

  };

  return (
    <Card className="h-100 bg-secondary text-white shadow-sm">
      {service.image && (
        <Card.Img
          variant="top"
          src={service.image}
          alt={service.name}
          style={{ height: '200px', objectFit: 'cover' }}
        />
      )}
      <Card.Body>
        <Card.Title>{service.name}</Card.Title>
        <Card.Text className="fw-bold text-warning">{service.price} VND</Card.Text>

        {service.quantity !== undefined && (
          <Card.Text className="text-white">Số lượng: {service.quantity}</Card.Text>
        )}

        {isAdmin ? (
          <>
            <Button
              size="sm"
              variant="warning"
              className="me-2"
              onClick={onEdit}
            >
              Sửa
            </Button>
            <Button size="sm" variant="danger" onClick={onDelete}>
              Xóa
            </Button>
          </>
        ) : (
          <Button
            size="sm"
            variant="light"
            onClick={handleAdd}
          >
            Thêm vào giỏ
          </Button>
        )}
      </Card.Body>
    </Card>
  );
}

ServiceCard.propTypes = {
  service: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string,
    price: PropTypes.number,
    image: PropTypes.string,
    quantity: PropTypes.number,
  }),
  isAdmin: PropTypes.bool,
  onEdit: PropTypes.func,
  onDelete: PropTypes.func,
};
