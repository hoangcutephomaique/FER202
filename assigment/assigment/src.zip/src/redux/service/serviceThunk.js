import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

const BASE_URL = 'http://localhost:3000/services';

// Lấy danh sách dịch vụ
export const fetchServices = createAsyncThunk('services/fetch', async () => {
  const res = await axios.get(BASE_URL);
  return res.data;
});

// Thêm dịch vụ
export const addService = createAsyncThunk('services/add', async (data, { dispatch }) => {
  await axios.post(BASE_URL, data);
  dispatch(fetchServices());
});

// Cập nhật dịch vụ
export const updateService = createAsyncThunk('services/update', async ({ id, data }, { dispatch }) => {
  await axios.put(`${BASE_URL}/${id}`, data);
  dispatch(fetchServices());
});

// Xóa dịch vụ
export const deleteService = createAsyncThunk('services/delete', async (id, { dispatch }) => {
  await axios.delete(`${BASE_URL}/${id}`);
  dispatch(fetchServices());
});

// ✅ Giảm số lượng dịch vụ sau khi thêm vào giỏ
export const reduceServiceQuantity = createAsyncThunk(
  'services/reduceQuantity',
  async (serviceId, { dispatch }) => {
    const res = await axios.get(`${BASE_URL}/${serviceId}`);
    const service = res.data;

    if (service.quantity > 0) {
      const updated = { ...service, quantity: service.quantity - 1 };
      await axios.put(`${BASE_URL}/${serviceId}`, updated);
      dispatch(fetchServices());
      return updated;
    } else {
      throw new Error('Số lượng dịch vụ đã hết');
    }
  }
);
